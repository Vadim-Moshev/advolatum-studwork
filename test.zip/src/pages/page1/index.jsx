import { Link } from "react-router-dom";

const Page1 = () => {
  return (
    <>
      <Link to="/page2">Вы на странице 1. Уйти на страницу 2</Link>
    </>
  );
};

export default Page1;
