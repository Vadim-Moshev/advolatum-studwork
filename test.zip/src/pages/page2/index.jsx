import { Link } from "react-router-dom";

const Page2 = () => {
  return (
    <>
      <Link to="/page1">Вы на странице 2. Уйти на страницу 1</Link>
    </>
  );
};

export default Page2;
